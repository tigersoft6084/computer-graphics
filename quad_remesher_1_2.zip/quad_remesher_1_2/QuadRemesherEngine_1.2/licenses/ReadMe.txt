1 - Quad-Remesher makes use of some Qt 5.6.2 libraries under the LGPL v2.1 license.
Quad-Remesher engine is using dynamic linking with these libraries. 

A copy of the GNU LGPL is included in QuadRemesher's distribution (in the file named "lgpl-2.1.txt"),
It may also be found online at this adress: http://www.gnu.org/licenses/lgpl-2.1.txt 

The source code for Qt 5.6.2 may be downloaded from Nokia at:  ftp://ftp.qt.nokia.com/qt/source/qt-everywhere-opensource-src-5.6.2.zip
The source code for Qt 5.6.2 may be obtained from EXOSIDE by asking at contact@exoside.com


2 - Quad-Remesher makes use of some libraries of SuiteSparse 5.6.0 under the LGPL v2.1 license.
Quad-Remesher engine is using dynamic linking with these libraries. 

A copy of the LGPL license for SuiteSparse is included in QuadRemesher's distribution (in the file named "lesser.txt"),

Quad-Remesher is using the following modules of the SuiteSparse library:
- AMD
- CAMD
- CCOLAMD
- COLAMD
- CholMod/Cholesky
- CholMod/Core

The source code for the SuiteSparse 5.6.0 library may be downloaded from: http://faculty.cse.tamu.edu/davis/suitesparse.html
The source code for the SuiteSparse 5.6.0 library may be obtained from EXOSIDE by asking at contact@exoside.com


